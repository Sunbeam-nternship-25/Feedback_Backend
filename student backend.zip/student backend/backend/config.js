const config = {

     secret: 'SQBOO51UX9j45ERfhLyGamVKIULPWYzI'
}

module.exports = config;